#ifndef CKS_H
#define CKS_H

void setFont(const char *font);
void setColor(const char *color);
void importCK(const char *filename);
void executeCKSFile(const char *filename);

#endif
